package com.emir.inventorymaster.mixin;

import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(HandledScreen.class)
public interface HandledScreenAccessor {
    @Accessor("x") int inventorymaster$getX();
    @Accessor("backgroundWidth") int inventorymaster$getBackgroundWidth();
}
