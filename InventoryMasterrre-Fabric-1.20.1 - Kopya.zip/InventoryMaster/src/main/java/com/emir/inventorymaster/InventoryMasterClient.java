package com.emir.inventorymaster;

import com.emir.inventorymaster.mixin.HandledScreenAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.SwordItem;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class InventoryMasterClient implements ClientModInitializer {
    private static final int BUTTON_WIDTH = 92;
    private static final int BUTTON_HEIGHT = 20;
    private static final int GAP = 4;

    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!(screen instanceof HandledScreen<?> handled)) return;
            HandledScreenAccessor accessor = (HandledScreenAccessor) handled;
            int x = accessor.inventorymaster$getX() + accessor.inventorymaster$getBackgroundWidth() + GAP;
            // Keep the controls visible on narrower screens by placing them just inside the right edge.
            if (x + BUTTON_WIDTH > scaledWidth) x = Math.max(2, scaledWidth - BUTTON_WIDTH - 2);
            int y = Math.max(4, (scaledHeight - (BUTTON_HEIGHT * 3 + GAP * 2)) / 2);

            screen.addDrawableChild(ButtonWidget.builder(Text.literal("Her Şeyi At"), b -> dropAll(client, handled.getScreenHandler()))
                    .dimensions(x, y, BUTTON_WIDTH, BUTTON_HEIGHT).build());
            screen.addDrawableChild(ButtonWidget.builder(Text.literal("Her Şeyi Al"), b -> takeAll(client, handled.getScreenHandler()))
                    .dimensions(x, y + BUTTON_HEIGHT + GAP, BUTTON_WIDTH, BUTTON_HEIGHT).build());
            screen.addDrawableChild(ButtonWidget.builder(Text.literal("Çöpleri At"), b -> dropTrash(client, handled.getScreenHandler()))
                    .dimensions(x, y + (BUTTON_HEIGHT + GAP) * 2, BUTTON_WIDTH, BUTTON_HEIGHT).build());
        });
    }

    private static boolean valid(MinecraftClient client, ScreenHandler handler) {
        return client.player != null && client.interactionManager != null
                && client.currentScreen instanceof HandledScreen<?>
                && handler == client.player.currentScreenHandler;
    }

    private static List<Integer> containerSlots(MinecraftClient client, ScreenHandler handler) {
        List<Integer> result = new ArrayList<>();
        if (client.player == null) return result;
        for (Slot slot : handler.slots) {
            if (slot.inventory != client.player.getInventory() && slot.hasStack()) result.add(slot.id);
        }
        return result;
    }

    private static void click(MinecraftClient client, ScreenHandler handler, int slotId, int mouseButton, SlotActionType type) {
        client.interactionManager.clickSlot(handler.syncId, slotId, mouseButton, type, client.player);
    }

    private static void dropAll(MinecraftClient client, ScreenHandler handler) {
        if (!valid(client, handler)) return;
        for (int id : containerSlots(client, handler)) click(client, handler, id, 1, SlotActionType.THROW);
    }

    private static void takeAll(MinecraftClient client, ScreenHandler handler) {
        if (!valid(client, handler)) return;
        // Quick-move each container stack into the player's inventory.
        for (int id : containerSlots(client, handler)) click(client, handler, id, 0, SlotActionType.QUICK_MOVE);
    }

    private static void dropTrash(MinecraftClient client, ScreenHandler handler) {
        if (!valid(client, handler)) return;
        int rockets = 0;
        for (Slot slot : handler.slots) {
            if (slot.inventory != client.player.getInventory() && slot.hasStack()
                    && slot.getStack().isOf(Items.FIREWORK_ROCKET)) {
                rockets += slot.getStack().getCount();
            }
        }
        boolean discardRockets = rockets > 512;

        // Iterate over a snapshot because each click changes the live slot contents.
        List<Integer> ids = containerSlots(client, handler);
        for (int id : ids) {
            Slot slot = handler.slots.get(id);
            if (!slot.hasStack()) continue;
            ItemStack stack = slot.getStack();
            boolean trash = stack.isOf(Items.SPIDER_EYE)
                    || stack.isOf(Items.STRING)
                    || (discardRockets && stack.isOf(Items.FIREWORK_ROCKET));

            if (stack.getItem() instanceof ArmorItem) {
                trash |= EnchantmentHelper.getLevel(Enchantments.PROTECTION, stack) < 10;
            }
            if (stack.getItem() instanceof SwordItem) {
                trash |= EnchantmentHelper.getLevel(Enchantments.SHARPNESS, stack) < 10;
            }
            if (stack.getItem() instanceof PickaxeItem) {
                trash |= EnchantmentHelper.getLevel(Enchantments.EFFICIENCY, stack) < 10;
            }
            if (trash) click(client, handler, id, 1, SlotActionType.THROW);
        }
    }
}
