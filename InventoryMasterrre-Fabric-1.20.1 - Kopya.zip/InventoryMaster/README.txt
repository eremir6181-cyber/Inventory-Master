INVENTORY MASTER - Fabric 1.20.1

Bu klasor modun kaynak kodudur. Mod istemci tarafinda calisir.

Ozellikler:
- Her Şeyi At: Acik sandik/envanter arayuzundeki oyuncuya ait olmayan slotlardaki esyalari atar.
- Her Şeyi Al: Acik sandiktaki esyalari hizli tasima ile oyuncu envanterine aktarir.
- Copleri At: Orumcek gozu ve ipi atar. Acik GUI'deki havai fisek roketlerinin toplam sayisi 512'yi asarsa GUI'deki roketleri atar. Koruma seviyesi 10'dan dusuk zirhlari, Keskinlik seviyesi 10'dan dusuk kiliclari ve Verimlilik seviyesi 10'dan dusuk kazmalari atar. Buyu yoksa seviye 0 sayilir.

DERLEME:
1. Bilgisayarda Java 17 ve Gradle 8.6 kurulu olsun.
2. Bu klasorde terminal ac.
3. gradle build komutunu calistir.
4. Olusan mod JAR'i build/libs/ klasorundedir.

Minecraft: Java 1.20.1
Mod yukleyici: Fabric
Gerekli: Fabric Loader ve Fabric API

Not: Butonlar ekranin saginda gorunur; ekran dar ise tasma olmasin diye sag kenara sigdirilir.
